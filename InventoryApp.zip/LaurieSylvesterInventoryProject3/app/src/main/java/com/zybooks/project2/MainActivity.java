package com.zybooks.project2;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private EditText editTextusername, editTextPassword, inputItemName, inputQuantity,
            inputNotes;
    private LoginDatabase loginDatabase;
    private InventoryDatabase inventoryDatabase;
    private Button loginButton, newLoginButton, addItemButton, viewInventoryButton;

    // Placeholder: Utilize for later development
    //private LinearLayout itemsContainer;
    private SensorManager mSensorManager;
    private Sensor mProximitySensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // default false
        SharedPreferences sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        AtomicBoolean isLoggedIn = new AtomicBoolean(sharedPreferences.getBoolean("isLoggedIn", false));
        if (isLoggedIn.get()) {
           showInventory();
        } else {
            editTextusername = findViewById(R.id.editTextUsername);
            editTextPassword = findViewById(R.id.editTextPassword);
            loginButton = findViewById(R.id.loginButton);
            newLoginButton = findViewById(R.id.createNewLoginButton);

            loginDatabase = new LoginDatabase(this);
            inventoryDatabase = new InventoryDatabase(this);

            // Add proximity sensor to enable SMS messaging
            mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            mProximitySensor = mSensorManager.getDefaultSensor(
                    Sensor.TYPE_PROXIMITY);

            loginButton.setOnClickListener(view -> {
                String username = editTextusername.getText().toString();
                String password = editTextPassword.getText().toString();

                if (loginDatabase.userExists(username)) {
                    //To DO: Validate/salt password
                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                    isLoggedIn.set(true);
                    showInventory();
                } else {
                    Toast.makeText(MainActivity.this, "Account does not exist. Please create account.", Toast.LENGTH_SHORT).show();
                }
            });

            newLoginButton.setOnClickListener(view -> {
                String username = editTextusername.getText().toString();
                String password = editTextPassword.getText().toString();

                try {
                    loginDatabase.addUser(username, password);
                    Toast.makeText(MainActivity.this, "Create account successful", Toast.LENGTH_SHORT).show();
                    isLoggedIn.set(true);
                    showInventory();
                } catch (Exception e) {
                    // May Throw exception if username or password are empty strings
                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
    }

    private void showInventory() {
        setContentView(R.layout.activity_inventory);

        inputItemName = findViewById(R.id.inputItemName);
        inputQuantity = findViewById(R.id.inputQuantity);
        inputNotes = findViewById(R.id.inputNotes);
        addItemButton = findViewById(R.id.addItemButton);
        viewInventoryButton = findViewById(R.id.viewInventoryButton);

        ImageButton settingsButton = findViewById(R.id.settingButton);
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        addItemButton.setOnClickListener(v -> {
            String itemName = inputItemName.getText().toString();
            int itemQuantity = Integer.parseInt(inputQuantity.getText().toString());
            String itemNotes = inputNotes.getText().toString();

            try {
                long addValReturned = inventoryDatabase.addItem(itemName, itemQuantity, itemNotes);
                    if (checkAddedForError(addValReturned)) {
                        inputItemName.setText("");
                        inputQuantity.setText("");
                        inputNotes.setText("");
                        refreshInventory();
                }
            } catch (Exception ex) {
                Log.e("ERROR IN MAIN ACTIVITY", "ADDING ITEM", ex);
                Toast.makeText(MainActivity.this, "Error adding item: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });

        viewInventoryButton.setOnClickListener(v -> {
            refreshInventory();
        });
    }

    private void refreshInventory() {
        GridLayout inventoryGrid = findViewById(R.id.inventoryGrid);
        if (inventoryGrid == null) return;

        // remove item rows but keep headers
        inventoryGrid.removeViews(6, inventoryGrid.getChildCount() - 6);

        List<InventoryItem> items = inventoryDatabase.showTableList();

        for (InventoryItem item: items) {
            addTextToGrid(inventoryGrid, item.getName(), 0);
            addTextToGrid(inventoryGrid, String.valueOf(item.getQuantity()), 1);
            addTextToGrid(inventoryGrid, item.getNotes(), 2);

            Button removeButton = new Button(this);
            removeButton.setText("Remove");
            removeButton.setOnClickListener(v -> {
                inventoryDatabase.deleteItem(item.getName());
                refreshInventory();
            });
            Button updateButton = new Button(this);
            updateButton.setText("Update");
            updateButton.setOnClickListener(v -> {
                showUpdateView(item);
            });
            addButtonToGrid(inventoryGrid, removeButton, 3);
            addButtonToGrid(inventoryGrid, updateButton, 4);
        }
    }

    private boolean checkAddedForError(long val) {
        if (val == -2) {
            Toast.makeText(MainActivity.this, "Item name cannot be empty, try again.", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (val == -3) {
            Toast.makeText(MainActivity.this, "Item name already exists, try again.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void addTextToGrid(GridLayout grid, String text, int colInd) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.columnSpec = GridLayout.spec(colInd, 1f);
        params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED);
        textView.setLayoutParams(params);
        grid.addView(textView);
    }


    private void addButtonToGrid(GridLayout grid, Button button, int colIndex) {
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = GridLayout.LayoutParams.WRAP_CONTENT;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(colIndex, 1f);
        params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED);
        params.setMargins(2,2,2,2);

        button.setTextSize(10);
        button.setPadding(0,0,0,0);
        button.setLayoutParams(params);
        grid.addView(button);
    }

    private void showUpdateView(InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Item Quantity");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("Enter new quantity");
        // current quantity
        input.setText(String.valueOf(item.getQuantity()));
        builder.setView(input);

        // Plus button
        builder.setPositiveButton("Update", (dialog, which) -> {
            try {
                int newQuantity = Integer.parseInt(input.getText().toString());
                item.setQuantity(newQuantity);
                inventoryDatabase.updateQuantity(item.getName(), newQuantity);
                refreshInventory();  //show updated UI
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Invalid quantity", Toast.LENGTH_SHORT).show();
            }
        });

        // Cancel
        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mProximitySensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this, mProximitySensor);
    }

    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            float proximity = sensorEvent.values[0];

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                !=PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, 1001);
            } else {
                Toast.makeText(this, "Permission has previously been given for SMS messaging.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}