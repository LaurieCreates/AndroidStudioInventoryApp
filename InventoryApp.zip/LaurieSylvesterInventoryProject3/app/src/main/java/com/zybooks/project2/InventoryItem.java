package com.zybooks.project2;

public class InventoryItem {
    public long id;
    public String name;
    public int quantity;
    public String notes;

    public InventoryItem(long id, String name, int quantity, String notes) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.notes = notes;
    }

    public long getId() {
        return id;
    }

    private void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
