package com.zybooks.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "login.db";
    private static final int VERSION = 1;

    public LoginDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable {
        private static final String TABLE = "login";
        private static final String COL_ID = "user_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    public long addUser(String username, String password) throws Exception {
        if (username.isEmpty() || password.isEmpty()) {
            throw new Exception("Enter text for username and password then click create account.");
        }

        if (userExists(username)) {
            throw new Exception("Username already exists");
        }

        SQLiteDatabase db = getWritableDatabase();

        // TO DO, SALT passwords
        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USERNAME, username);
        values.put(LoginTable.COL_PASSWORD, password);

        return db.insert(LoginTable.TABLE, null, values);
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(LoginDatabase.LoginTable.TABLE, null, LoginTable.COL_USERNAME + " = ?",
                new String[]{username.toLowerCase()}, null, null, null);
        boolean exists = (cursor.getCount() > 0);

        cursor.close();
        return exists;
    }
}
