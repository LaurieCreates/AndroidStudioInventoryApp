package com.zybooks.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_NOTES = "notes";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_NAME + " text, " +
                InventoryTable.COL_QUANTITY + " integer, " +
                InventoryTable.COL_NOTES + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    public long addItem(String name, @NonNull Integer quantity, String notes) {
        if (name.isEmpty()) {
            return -2;
        }

        if (itemExists(name)) {
            return -3;
        }

        SQLiteDatabase db = getWritableDatabase();

        // FIX THESE VALUES HERE
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_QUANTITY , quantity);
        values.put(InventoryTable.COL_NOTES, notes);

        return db.insert(InventoryTable.TABLE, null, values);
    }

    private boolean itemExists(String itemName) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(InventoryDatabase.InventoryTable.TABLE, null, InventoryTable.COL_NAME + " = ?",
                new String[]{itemName.toLowerCase()}, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    public boolean updateQuantity(String name, int quantity) throws Exception {
        SQLiteDatabase db = getWritableDatabase();

        if (!itemExists(name)) {
            throw new Exception("Item does not exist, please create new item before updating the " +
                    "quantity");
        }

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QUANTITY, quantity);

        int rowsUpdated = db.update(InventoryTable.TABLE, values, InventoryTable.COL_NAME +
                " = ?",
                new String[] {name});
        return rowsUpdated > 0;
    }

    public void deleteItem(String name) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(InventoryTable.TABLE, InventoryTable.COL_NAME + " = ?",
                new String[]{name});
        db.close();
    }

    public List<InventoryItem> showTableList() {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(InventoryTable.TABLE, null, null,
                null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
               long id = cursor.getLong(cursor.getColumnIndexOrThrow(InventoryTable.COL_ID));
               String name = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_NAME));
               int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(InventoryTable.COL_QUANTITY));
               String notes = cursor.getString(cursor.getColumnIndexOrThrow(InventoryTable.COL_NOTES));

               itemList.add(new InventoryItem(id, name, quantity, notes));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return itemList;
    }
}
