package com.zybooks.project2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.ActionBar;

public class SettingsActivity extends AppCompatActivity {
    private Button allowSMSButton, dontAllowSMSButton;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        allowSMSButton = findViewById(R.id.allowSMSButton);
        dontAllowSMSButton = findViewById(R.id.dontAllowSMSButton);

        // Get SharedPreferences (you can use this to save settings)
        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        // Enable the buttons if permissions are granted
        if (sharedPreferences.getBoolean("smsPermissionGranted", false)) {
            allowSMSButton.setEnabled(false);
            dontAllowSMSButton.setEnabled(true);
        } else {
            allowSMSButton.setEnabled(true);
            dontAllowSMSButton.setEnabled(true);
        }

        allowSMSButton.setOnClickListener(view -> {
            // Set preference and handle button state
            sharedPreferences.edit().putBoolean("smsPermissionGranted", true).apply();
            updateButtonState();

            // Return to InventoryActivity after making a choice
            goToInventory();
        });

        dontAllowSMSButton.setOnClickListener(view -> {
            // Set preference and handle button state
            sharedPreferences.edit().putBoolean("smsPermissionGranted", false).apply();
            updateButtonState();

            goToInventory();
        });
    }

    private void updateButtonState() {
        if (sharedPreferences.getBoolean("smsPermissionGranted", false)) {
            allowSMSButton.setEnabled(false);
            dontAllowSMSButton.setEnabled(true);
        } else {
            allowSMSButton.setEnabled(true);
            dontAllowSMSButton.setEnabled(false);
        }
    }

    private void goToInventory() {
        // Start MainActivity to go back to login screen
        // To Do: For now, login screen will show again but will save settings
        // Refactor to show inventory instead of only launching inventory after login
        Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
        startActivity(intent);
        finish();  // Close SettingsActivity
    }
}